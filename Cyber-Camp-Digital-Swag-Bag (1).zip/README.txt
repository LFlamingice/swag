   _____ ___    _   _______
  / ___//   |  / | / / ___/
  \__ \/ /| | /  |/ /\__ \ 
 ___/ / ___ |/ /|  /___/ / 
/____/_/  |_/_/ |_//____/  


Welcome to SANS Cyber Camp for Teens!


This is your Digital Swag Bag:

Solve the Cyber Camp Games word and number challenges to win a $50 Amazon gift card!
Submit your answers here!! **** https://sansurl.com/cyber-camp-games ****

Remember to check our blog for updates and presentation notes during and after the camp.
We'll also post the answer key to Cyber Camp Games to the blog after the event.
 - https://www.sans.org/blog/cyber-camp-blog-in-real-time/

We have background/wallpaper Cyber Camp images available for your computer, phone, and Zoom.

A Matrix style Advice background for you to use.

An advice column, Entering the Field of Cybersecurity.
 - https://www.sans.org/blog/entering-the-field-of-cybersecurity/
 - 10 Coolest Jobs in Cybersecurity poster for you to check out
 - Infographic from the advice column

We've included a copy of the agenda for reference.


Enjoy the camp!